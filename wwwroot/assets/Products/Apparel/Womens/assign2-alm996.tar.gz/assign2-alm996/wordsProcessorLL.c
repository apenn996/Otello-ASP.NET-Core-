#include "wordsProcessorLL.h"
//function definitions provided here
linkedList newList(){
	//allocate memory for a list
        linkedList list = (ListImp*)malloc(sizeof(ListImp));
        list->head = NULL;
        list->foot = NULL;
        list->totalWordCount = 0;
        return list;
}

NodeLL* allocateNode(Word myword){
	//allocate memory for a new node
        NodeLL* newNode = NULL;
        newNode = (NodeLL*)malloc(sizeof(NodeLL));
        if(newNode == NULL)
                printf("Error allocating a new node\n");
        newNode->next = NULL;
	//initialize node with word
        newNode->myword = myword;
        return newNode;
}

int isEmpty(linkedList list){
        if(list->head == NULL)
                return 1;
        else
                return 0;
}

void attatchtoList(linkedList list, Word myword){
	//if list is empty, set list head to new node, else make new node the new foot
        if(isEmpty(list) == 1){
                list->head = allocateNode(myword);
                list->foot = list->head;
        }
        else{
                list->foot->next = allocateNode(myword);
                list->foot = list->foot->next;
        }
}

linkedList countWordsWithLinkedList(FILE* file){
        int inId;
        inId = fileno(file);
        int blockSize = 20000;
        char buffer[blockSize]; //buffer to parse through
        char* temp; //string to hold every word
        char* delimiters = " \n.,\"?!\()"; //delimiter list
        int myRead; //result of read call
        int totalWordCount = 0; //word count
        linkedList thislist = newList();
        while ((myRead = read(inId, buffer, blockSize)) > 0) {
                //grab first word separated by any delimiter from list using strtok
                temp = strtok(buffer, delimiters);
                while (temp != NULL){
                        Word myword;
                        myword.word = temp;
			
			//search the list for the current word
                        int result = searchlist(thislist->head, thislist, myword.word);
                        totalWordCount++;
                        //go to next word in buffer that is separated by a delimiter
                        temp = strtok(NULL, delimiters);
                }
        }
        thislist->totalWordCount = totalWordCount;
        return thislist;
}

int searchlist(NodeLL *p,linkedList list, char* string){
	//if current word is not found by the end of the list, attatch a new node for the word to the list
        if(p == NULL){
                Word myword={0,""};
                myword.word = string;
                myword.occurrences=1;
                attatchtoList(list, myword);
                return -1;
        }
	//if that word is found, increment its occurrence count
        if(strcasecmp(p->myword.word,string) == 0 ){
                p->myword.occurrences++;
                return 0;
        }
        searchlist(p->next, list, string);
}

//count number of nodes in the list
int getLength(NodeLL *head) {
        int len = 0;
        NodeLL *curr = head;
        while (curr != NULL) {
                len++;
                curr = curr->next;
        }
        return len;
}

NodeLL* sortLinkedList(NodeLL* head){
        int len = getLength(head);
        int itr = 0;
        int swapped;
	//bubblesort based on alphabetical values
        while(itr < len){
                NodeLL* traverseNode = head;
                NodeLL* prevNode = head;
                swapped=0;
                while(traverseNode->next != NULL){
                        NodeLL* ptr = traverseNode->next;
                        if(strcasecmp(traverseNode->myword.word, ptr->myword.word) > 0){
                                swapped = 1;
                                if(traverseNode == head){
                                        traverseNode->next = ptr->next;
                                        ptr->next = traverseNode;
                                        prevNode = ptr;
                                        head = prevNode;
                                }else{
                                        traverseNode->next = ptr->next;
                                        ptr->next = traverseNode;
                                        prevNode->next = ptr;
                                        prevNode = ptr;
                                }
                                continue;
                        }
                        prevNode = traverseNode;
                        traverseNode = traverseNode->next;
                }
                if(!swapped){
                        break;
                }
                ++itr;
        }
return head;
}

//iterate through the list and print each node
int printWordsLinkedList(NodeLL *p, int count){
        if(p == NULL){
                return count;
        }
        printf("%s appears %d times\n", p->myword.word, p->myword.occurrences);
        count++;
        printWordsLinkedList(p->next, count);
}
