#include "wordsProcessorLL.h"
//Created by Austin Pennartz
int main( int argc, char* argv[] ){
	printf("Created By Austin Pennartz!\n\n");
	int inId; //file desriptor for current open file
	int exitStatus; //exit status of child process
	int childId; //child process id
	int fd[2]; //pipe for reading and writing between child and parent processes
	int uniqueWordCount; //count of unique words for a child process
	int totalWordCount = 0;//count of total words for a child process
	int twc=0; //sum count of total words for all processes
	int uwc=0; //sum count of unique words for all processes

	if (argc < 3){ //if arguments less than required throw error
		printf("Error: Not enough arguments (need at least 2)\n");
		return 1;
	}
	
	int i;
	for(i=1; i<argc; i++){
		pipe(fd); //create pipe
		inId = fopen(argv[i], "r"); //open current file for reading
		childId = fork(); //spawn a child process with fork
		linkedList list = NULL;
		switch(childId){
			case -1: //error case
				printf("ERROR: fork failed\n");
			case 0: //child case
				printf("The file %s has:\n", argv[i]);
				list = countWordsWithLinkedList(inId);//create and fill list
				list->head = sortLinkedList(list->head);//alphabetically sort the list
				int count = 0;
				count =  printWordsLinkedList(list->head, count);//print list 
				uniqueWordCount = count;
				totalWordCount = list->totalWordCount;
				close(fd[0]);

				write(fd[1], &totalWordCount, sizeof(totalWordCount));//writing total and unique words counts for a child process to the pipe so the parent can read them. 
				write(fd[1], &uniqueWordCount, sizeof(uniqueWordCount));
				close(fd[1]);
				exit(0);
				break;
			default:

				printf(""); //parent does nothing
		}
		//parent reads counts from child from the pipe and prints them
		close(fd[1]);
		read(fd[0], &totalWordCount, sizeof(totalWordCount));
		twc += totalWordCount;
		printf("++++++++++    Total Words: %d    ++++++++++\n", totalWordCount);
		read(fd[0], &uniqueWordCount, sizeof(uniqueWordCount));
		close(fd[0]);
		uwc += uniqueWordCount;
		printf("++++++++++   Unique Words: %d    ++++++++++\n", uniqueWordCount);
		printf("\n");
		printf("\n");
	}
	printf("The total number of words is: %d; number of different words is %d \n", twc, uwc);
	int argCount;
	argCount = argc - 1;
        //parent waits for child processes to finish executing
	while (argCount !=0){

		wait(&exitStatus);
		argCount--;
	}
	return 0;
}
