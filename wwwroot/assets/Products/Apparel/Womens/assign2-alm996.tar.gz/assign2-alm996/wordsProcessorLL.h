#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>

#ifndef WORDSPROCESSOR_H
#define WORDSPROCESSOR_H

//Node word properties
typedef struct{
        int occurrences;
        char* word;
} Word;

//linked list node struct
typedef struct NodeLL{
        Word myword;
        struct NodeLL* next;
} NodeLL;

//Linked list struct
typedef struct{
        NodeLL *head;
        NodeLL *foot;
        int totalWordCount;
} ListImp;

//pointer to a list
typedef ListImp *linkedList;

//allocates memory for a new linked list and returns a pointer to the list.
linkedList newList();

//allocates memory for a new linked list node and returns a pointer to it. 
NodeLL* allocateNode(Word myword);

//checks if a linked list is empty and returns true or false
int isEmpty(linkedList list);

//appends a new node to the end of a linked list
void attatchtoList(linkedList list, Word myword);

//handles the counting of the total and unique words for a linked list. parses through file and adds the word to the linked list if it isnt already there. Otherwise increment its counter. 
//returns a linked list with the relevant information for the current file. 
linkedList countWordsWithLinkedList(FILE* file);

//searches the linked list for the current word, increment occurences if found, otherwise add it to the linked list.
int searchlist(NodeLL *p, linkedList, char* string);

//gets the length in Nodes for the linked list
int getLength(NodeLL *head);

//sorts the linked list nodes in alphabetical, non case sensitive order using bubblesort.
NodeLL* sortLinkedList(NodeLL* head);

//prints the contents of a linked list.
int printWordsWithLinkedList(NodeLL* p, int count);


#endif
