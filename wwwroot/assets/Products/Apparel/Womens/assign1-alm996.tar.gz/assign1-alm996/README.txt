a) This program is 100% completed and works correctly on all given input files
b) First extract the tarball: tar -zcvf assign1-alm996.tar.gz assign1-alm996
   Next, use the cd command to go into the assign1-alm996 folder: cd assign1-alm996
   Now to compile this program type: gcc proj1-main.c -o textfile-ops
   To execute this program type: ./textfile-ops input-file.txt output-file-name.txt
c) I recieved no help from any other students
d) I wish it was more clear whether we should use low level system calls like open, create, read, and close or if we could used fopen, fclose, fgets, etc. 
