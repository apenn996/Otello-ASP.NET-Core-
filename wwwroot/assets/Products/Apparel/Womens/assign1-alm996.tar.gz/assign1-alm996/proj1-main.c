#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
int main( int argc, char* argv[] ){
	int blockSize = 20000;
	char buffer[blockSize]; //buffer to parse through
	char* temp; //string to hold every word
	char* delimiters = " \n.,\"?!\()"; //delimiter list
	int outId; //write file identifier
	int inId; //read file identifier
	int myRead; //result of read call
	int myWrite; //result of write call
	int words = 0; //word count

	//make sure the user supplied a input file and if not return error message
	if (argc < 3){
		printf("Error: Not enough arguments\n");
		return 1;
	}	
	//open input file
	inId = open(argv[1], O_RDONLY);

	//make sure the input file given can open and if not return an error message. If it did open return a success message
	if(inId < 0){
		printf("Error: The specified input file could not be found.\n");
		return 1;
	}
	else{
		printf("The input file, \"%s\" was opened successfully!\n", argv[1]);
	}
	

	//create an output file and make sure it create successfully
	outId = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0777);
	if(outId != -1){
		printf("The output file was created successfully.\n");
	}

	//read from input file buffer 
	while ((myRead = read(inId, buffer, blockSize)) > 0) {

		//grab first word separated by any delimiter from list using strtok
		temp = strtok(buffer, delimiters);
		while (temp != NULL){
			
			//write current word to output file
			myWrite = write(outId, temp, strlen(temp));
			//add a newline character to each word
			write(outId, "\n", 1);
			//increment word count
			words++;	
			//go to next word in buffer that is separated by a delimiter
			temp = strtok(NULL, delimiters);
		}

	}
	//close input and output files
	close(outId);
	close(inId);	

	//print total word count
	printf("The total number of words is: %d.\n", words);
	return 0;
}
